image resizing api 

steps to run the file 

1- sudo run build : to download the dep needed
2- sudo run start : to resize the image

the server port is 8000 
the url is : http://localhost:8000/images?filename=1&width=200&height=200
