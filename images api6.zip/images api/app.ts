import express from 'express';
import * as fs from 'fs';
const sharp =require('sharp')
const app = express();
const { promises } = require('fs');


const port = process.env.PORT || 8000;
app.listen(port, () => {
  console.log(`server running on port:${port} `);
});

const resize = async (req , res, next: () => void) => {
   sharp('${req.query.filename}').resize(parseInt(req.query.width), parseInt(req.query.height)).toFile('outimg.jpg');
  next();
};

const sendBack = async ( res: { end: (arg0: Buffer) => void; }, next: () => void) => {
   fs.readFile('outimg.jpg', function (err, data) {
    if (err) console.log('oops , something is wrong pls try again'); 
    res.end(data); 
  });
  next();
};


app.get('/', (req , res: { send: (arg0: string) => void; }) => {
  res.send('wokring');
});

app.get('/api/images', resize, sendBack, (req: any, res: any) => {});
